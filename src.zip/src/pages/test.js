import React from 'react'

export default function test() {
  return (
    <div>test</div>
  )
}





skdfgoisdfgi

sdfgnskjdfgjsdf


const m1 = (a , b) =>{
    console.log(a + b);
}
m1(10 , 20);




///////////////////////////////css

nav > ul > li {

}


/////////////////////////////////sass

nav {

    ul {

        li{
             
        }
    }
}







